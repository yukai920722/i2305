<?php
 $db_host = "localhost";
 $db_name = "ksu_database";
 $db_table = "ksu_std_table";
 $db_user = "root";
 $db_password = "";
 // check connection
 $conn = mysqli_connect($db_host, $db_user, $db_password);
 if(empty($conn)){
	print  mysqli_error ($conn);
    die ("Unable to connect to DB！" );
	exit;
 }  
 if(!mysqli_select_db( $conn, $db_name)){
	die("DB is not existed");
	exit;
 }  
 //main scope  

  
   
 echo "<table border='1'>
 <tr>
   <th> Department </th>  <th> the number of students </th> 
 </tr>";

?> 
<form enctype="multipart/form-data"  >
<input type="submit" name="sub" value="Back"/>
</form>